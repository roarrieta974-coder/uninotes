package com.example.uninotes

import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class NoteCanvas(context: android.content.Context): View(context) {
    private val paths = mutableListOf<Path>()
    private var current: Path? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(55,45,70); style = Paint.Style.STROKE; strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(255,253,255))
        val grid = Paint().apply { color=Color.rgb(230,225,235); strokeWidth=1f }
        var y=72f
        while(y<height){ c.drawLine(0f,y,width.toFloat(),y,grid); y+=72f }
        paths.forEach { c.drawPath(it, paint) }
        current?.let { c.drawPath(it, paint) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN -> { current=Path().apply{moveTo(e.x,e.y)}; parent.requestDisallowInterceptTouchEvent(true); invalidate(); return true }
            MotionEvent.ACTION_MOVE -> { current?.lineTo(e.x,e.y); invalidate(); return true }
            MotionEvent.ACTION_UP -> { current?.let{paths.add(it)}; current=null; invalidate(); return true }
        }; return true
    }
    fun clearPage(){ paths.clear(); current=null; invalidate() }
}

class MainActivity: androidx.appcompat.app.AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var canvas: NoteCanvas
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showHome()
    }
    private fun bg(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(250,248,255)); cornerRadius=28f
    }
    private fun showHome(){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(36,48,36,24); setBackgroundColor(Color.rgb(250,248,255))}
        val title=TextView(this).apply{ text="UniNotes"; textSize=34f; setTextColor(Color.rgb(45,38,55)); setTypeface(null,1)}
        val sub=TextView(this).apply{ text="Tus apuntes, organizados y siempre a mano"; textSize=16f; setTextColor(Color.GRAY); setPadding(0,4,0,28)}
        root.addView(title); root.addView(sub)
        val add=Button(this).apply{ text="＋  Nuevo apunte"; setOnClickListener{showEditor()} }
        root.addView(add, LinearLayout.LayoutParams(-1,64))
        val section=TextView(this).apply{ text="Materias"; textSize=22f; setTypeface(null,1); setPadding(0,30,0,12)}
        root.addView(section)
        listOf("📐 Matemática","🧬 Biología","💻 Programación","📖 Historia").forEach { name ->
            val card=Button(this).apply{ text="$name\n3 apuntes"; textSize=17f; gravity=Gravity.CENTER_VERTICAL or Gravity.START; background=bg()
                setPadding(24,0,0,0); setOnClickListener{showEditor()} }
            val lp=LinearLayout.LayoutParams(-1,92); lp.setMargins(0,8,0,8); root.addView(card,lp)
        }
        setContentView(root)
    }
    private fun showEditor(){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(255,253,255))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL; setPadding(16,10,16,10); gravity=Gravity.CENTER_VERTICAL}
        val back=Button(this).apply{text="‹"; textSize=28f; setOnClickListener{showHome()}}
        val name=TextView(this).apply{text="  Matemática — Apunte 1"; textSize=19f; setTypeface(null,1); gravity=Gravity.CENTER_VERTICAL}
        val undo=Button(this).apply{text="↶"; textSize=22f}
        val erase=Button(this).apply{text="⌫"; textSize=20f; setOnClickListener{canvas.clearPage()}}
        bar.addView(back,LinearLayout.LayoutParams(60,60)); bar.addView(name,LinearLayout.LayoutParams(0,60,1f)); bar.addView(undo,LinearLayout.LayoutParams(60,60)); bar.addView(erase,LinearLayout.LayoutParams(60,60))
        root.addView(bar)
        canvas=NoteCanvas(this); root.addView(canvas,LinearLayout.LayoutParams(-1,0,1f))
        val tools=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(8,8,8,8)}
        listOf("✎ Lápiz","🖍 Resaltador","□ Borrador","＋ Página").forEach{t->tools.addView(Button(this).apply{text=t},LinearLayout.LayoutParams(0,60,1f))}
        root.addView(tools); setContentView(root)
    }
}