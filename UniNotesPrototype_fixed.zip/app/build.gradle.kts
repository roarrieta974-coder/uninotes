plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
dependencies { implementation("androidx.appcompat:appcompat:1.7.0") }
android { namespace = "com.example.uninotes"; compileSdk = 35
    defaultConfig { applicationId = "com.example.uninotes"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
